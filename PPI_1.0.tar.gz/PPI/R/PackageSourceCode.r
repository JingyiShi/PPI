#' @title A Publication-based Popularity Index (PPI)
#'
#' @description The formula and properties of PPI are elaborated in the paper titled "A Publication-based Popularity Index (PPI) for Healthcare Dataset Ranking." The PPI is an index originally modeled for healthcare dataset evaluation purposes, but it can also be used in a broader context.
#' @param P A vector, publication numbers in each year.
#' @param weight Optional. A vector, the weight of each year. Default to be equal weights.
#' @return The PPI result.
#' @examples
#' PPI(c(71, 105, 121, 155, 200))
#' PPI(c(71, 105, 121, 155, 200), c(1, 2, 3, 4, 5))
#' @export

PPI <- function(P, weight = seq(1, 1, length.out = length(P))){
	if(length(P)>1 && all(P >= 0) && length(weight) == length(P)){
	  N = length(P)
		x = c(1:N)
		fit = lm(P ~ x, weights = weight)
		betahat = summary(fit)$coefficients[2, 1]
		exponent = log(abs(log(abs(betahat)))) * sign(betahat)
		if(abs(betahat) <= exp(1)){betahat=0; exponent=0;}
		return(mean(P) * exp(exponent))
	}
	else{
		stop("Error: Input must be valid: P is a vector, length(P)>1 && all(P >= 0). If input weight, weight is a vector, length(weight) == length(P).")
	}
}

#' @title A Publication-based Popularity Index (PPI) with plot for data points
#'
#' @param P A vector, publication numbers in each year.
#' @param weight Optional. A vector, the weight of each year. Default to be equal weights.
#' @return The PPI result and a plot of data points with a trend line according to weights.
#' @examples
#' PPI.plot(c(71, 105, 121, 155, 200))
#' PPI.plot(c(71, 105, 121, 155, 200), c(1, 2, 3, 4, 5))
#' @export

PPI.plot <- function(P, weight = seq(1, 1, length.out = length(P))){
  if(length(P)>1 && all(P >= 0) && length(weight) == length(P)){
    N = length(P)
    x = c(1:N)
    plot(x, P)
    fit = lm(P ~ x, weights = weight)
    abline(fit)
    betahat = summary(fit)$coefficients[2, 1]
    exponent = log(abs(log(abs(betahat)))) * sign(betahat)
    if(abs(betahat) <= exp(1)){betahat=0; exponent=0;}
    return(mean(P) * exp(exponent))
  }
  else{
    stop("Error: Input must be valid: P is a vector, length(P)>1 && all(P >= 0). If input weight, weight is a vector, length(weight) == length(P).")
  }
}
